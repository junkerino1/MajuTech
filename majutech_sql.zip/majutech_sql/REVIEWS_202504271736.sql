INSERT INTO MASTER.REVIEWS (COMMENT,RATING,USERNAME,ORDER_ID,PRODUCT_ID,REPLY_ID) VALUES
	 ('',5,'ethan',313,14,NULL),
	 ('',5,'ethan',213,10,NULL),
	 ('Highly Recommended! Mantap MajuTech! Hope my grandma will love my gift!',5,'e****',414,9,NULL),
	 ('Good! It deserves 5 star rating!',1,'junkang',415,16,NULL);
