INSERT INTO MASTER.CATEGORIES (CATEGORY_NAME) VALUES
	 ('Audio'),
	 ('PC & Laptop'),
	 ('Mobile Phone'),
	 ('Accessories'),
	 ('Lifestyle'),
	 ('Tablet');
