INSERT INTO MASTER.USERS (PASSWORD,USERNAME,EMAIL,PHONE,GENDER) VALUES
	 ('123','ethan',NULL,NULL,NULL),
	 ('test','jovel','jovel@gmail.com','01116326494','male'),
	 ('123','junkang','junkang@gmail.com','012345678','female');
