INSERT INTO MASTER.REPLIES (COMMENT,USERNAME,REVIEW_ID) VALUES
	 ('test',NULL,1),
	 ('test','chunjia',2),
	 ('Thank you for your support! We will provide more decent products for you in the future!','chunjia',3),
	 ('bro u give us one star only...... pala bapak kau......','chunjia',4);
