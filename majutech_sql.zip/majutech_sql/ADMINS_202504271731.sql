INSERT INTO MASTER.ADMINS (PASSWORD,"ROLE",USERNAME) VALUES
	 ('123456','manager','chunjia'),
	 ('123456','staff','chunwen'),
	 ('123456','staff','shunbin');
