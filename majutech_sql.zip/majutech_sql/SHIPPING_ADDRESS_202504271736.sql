INSERT INTO MASTER.SHIPPING_ADDRESS (PHONE_NUMBER,POSTCODE,STATE,STREET1,STREET2,USER_ID,NAME) VALUES
	 ('01116326494',47610,'Selangor','test123','test123',1,'Ethan'),
	 ('01116326494',47610,'Selangor','test456','test456',2,'Ethan'),
	 ('01172754858',53300,'Kuala Lumpur','A-38-09, PV18 Residency, Jalan Langkawi, Taman Setapak','',1,'CHAW CHUN JIA'),
	 ('01172754858',53300,'Kuala Lumpur','A-38-09, PV18 Residency, Jalan Langkawi, Taman Setapak','',103,'CHAW CHUN JIA');
