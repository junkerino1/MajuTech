INSERT INTO MASTER.PRODUCTS (CATEGORY_ID,IMAGE1,IMAGE2,IMAGE3,IMAGE4,PRODUCT_NAME,STATUS,UNIT_PRICE,DESCRIPTION,SPECIFICATION,QUANTITY) VALUES
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744956314/majutech_products/jgt2tcr2gsxx9sihxxgj.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744956317/majutech_products/ubjaerwoc6znufmmirbg.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744956319/majutech_products/tutlepjbmbjkgbehkzee.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744956322/majutech_products/vv4xttrhjddyptcvnojh.png','ASUS TUF A16 FA608W-VQT036W Gaming Laptop | AMD Ryzen AI 9 HX 370 | NVD RTX4060 8GB','normal',2399.0,'<b>Processor</b><br>
AMD Ryzen AI 9 HX 370 Processor 2.0GHz 36MB Cache, up to 5.1GHz, 12 cores, 24 Threads; AMD XDNA NPU up to 50TOPS<br><br>

<b>Graphics</b><br>
NVIDIA GeForce RTX 4060 Laptop GPU 233 AI TOPs, 2420MHz at 140W 2370MHz Boost Clock + 50MHz OC, 115W + 25W Dynamic Boost, 8GB GDDR6<br><br>

<b>Neural Processor</b><br>
AMD XDNA NPU up to 50TOPS<br><br>

<b>Display</b><br>
16-inch, 2.5K 2560 x 1600 WQXGA 16:10 aspect ratio, IPS-level, Anti-glare display, sRGB 100%, Adobe 75.35%, Refresh Rate 165Hz, G-Sync, MUX Switch + NVIDIA Advanced Optimus<br><br>

<b>Memory</b><br>
8GB x2 LPDDR5X 7500 on board, Max Capacity 16GB<br><br>

<b>Storage</b><br>
1TB PCIe 4.0 NVMe M.2 SSD<br><br>

<b>Expansion Slots includes used</b><br>
2x M.2 PCIe<br><br>

<b>I/O Ports</b><br>
1x 3.5mm Combo Audio Jack<br>
1x HDMI 2.1 FRL<br>
2x USB 3.2 Gen 2 Type-A data speed up to 10Gbps<br>
1x USB 3.2 Gen 2 Type-C with support for DisplayPort / power delivery / G-SYNC data speed up to 10Gbps<br>
1x RJ45 LAN port<br>
1x Type-C USB 4 with support for DisplayPort data speed up to 40Gbps<br><br>

<b>Keyboard and Touchpad</b><br>
Backlit Chiclet Keyboard 1-Zone RGB<br>
Touchpad<br>
With Copilot key Copilot in Windows in preview is rolling out gradually within the latest update to Windows 11 in select global markets. Timing of availability varies by device and market.<br><br>

<b>Camera</b><br>
1080P FHD IR Camera for Windows Hello<br><br>

<b>Audio</b><br>
Dolby Atmos<br>
AI noise-canceling technology<br>
Hi-Res certification for headphone<br>
Support Microsoft Cortana near field/far field Microsoft service suspended in spring of 2023<br>
Built-in array microphone<br>
2-speaker system<br><br>

<b>Network and Communication</b><br>
Wi-Fi 6E 802.11ax Triple band 2x2 + Bluetooth 5.3 Wireless Card Bluetooth version may change with OS version different<br><br>

<b>Battery</b><br>
90WHrs, 4S1P, 4-cell Li-ion<br><br>

<b>Power Supply</b><br>
Rectangle Conn, 240W AC Adapter, Output 20V DC 12A 240W, Input 100~240V AC 50/60Hz universal<br><br>

<b>AURA SYNC</b><br>
Yes<br><br>

<b>Weight</b><br>
2.20 Kg 4.85 lbs<br><br>

<b>Dimensions W x D x H</b><br>
35.4 x 26.9 x 1.79 ~ 2.57 cm 13.94 x 10.59 x 0.70 ~ 1.01 in<br><br>

<b>Warranty</b><br>
2Y Warranty<br>
','<li>16GB RAM</li>
<li>1TB SSD</li>
<li>NVD RTX4060 8GB</li>
<li>16" (2560 x 1600) 165Hz</li>
<li>Win11</li>
<li>Operating System: Windows 11 Home</li>
',98),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744956513/majutech_products/svsojlypcoo8kjxnjprx.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744956515/majutech_products/gbrwtwelmc1mhrolslga.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744956518/majutech_products/kggpr7tur0lh0uvrrkjr.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744956520/majutech_products/rffd2hezb5azbht9gmy7.png','Acer Nitro V14 ANV14-61-R9D1 Gaming Laptop | AMD Ryzen 7-8845HS','normal',3999.0,'<b>Processor Type</b><br>
Ryzen 7<br><br>

<b>Processor Model</b><br>
8845HS<br><br>

<b>Processor Speed</b><br>
3.80 GHz<br><br>

<b>Processor Speed Turbo</b><br>
5.10 GHz<br><br>

<b>Processor Core</b><br>
Octa-core 8 Core<br><br>

<b>Memory Card Reader</b><br>
Yes<br><br>

<b>Memory Card Supported</b><br>
microSD<br><br>

<b>Total Solid State Drive Capacity</b><br>
1 TB<br><br>

<b>Solid State Drive Interface</b><br>
PCI Express NVMe 4.0<br><br>

<b>Display Screen Type</b><br>
LCD<br><br>

<b>Display Screen Technology</b><br>
ComfyView Matte, In-plane Switching IPS Technology<br><br>

<b>Screen Mode</b><br>
WQXGA<br><br>

<b>Touchscreen</b><br>
No<br><br>

<b>Screen Resolution</b><br>
2560 x 1600<br><br>

<b>Graphics Controller Manufacturer</b><br>
NVIDIA<br><br>

<b>Graphics Controller Model</b><br>
GeForce RTX 4050<br><br>

<b>Graphics Memory Capacity</b><br>
6 GB<br><br>

<b>Graphics Memory Technology</b><br>
GDDR6<br><br>

<b>Graphics Memory Accessibility</b><br>
Dedicated<br><br>

<b>Speakers</b><br>
Yes<br><br>

<b>Number of Speakers</b><br>
2<br><br>

<b>Wireless LAN</b><br>
Yes<br><br>

<b>Wireless LAN Standard</b><br>
IEEE 802.11ax<br><br>

<b>Bluetooth</b><br>
Yes<br><br>

<b>Bluetooth Standard</b><br>
Bluetooth 5.3 or above<br><br>

<b>Microphone</b><br>
Yes<br><br>

<b>Fingerprint Reader</b><br>
No<br><br>

<b>HDMI</b><br>
Yes<br><br>

<b>Total Number of USB Ports</b><br>
3<br><br>

<b>Network RJ-45</b><br>
No<br><br>

<b>Audio Line In</b><br>
Yes<br><br>

<b>Audio Line Out</b><br>
Yes<br><br>

<b>Pointing Device Type</b><br>
TouchPad<br><br>

<b>Keyboard Included</b><br>
Yes<br><br>

<b>Keyboard Backlight</b><br>
Yes<br><br>

<b>Battery Chemistry</b><br>
Lithium Polymer Li-Polymer<br><br>

<b>Weight Approximate</b><br>
1.70 kg<br>
','<li>16GB RAM</li>
<li>1TB SSD</li>
<li>14" (2560 x 1600) 120Hz</li>
<li>NVD RTX4050 6GB</li>
<li>Win11</li>
<li>2Y Warranty</li>
',101),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744956810/majutech_products/s0a8ybdpwbw0cwhl0kxo.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744956813/majutech_products/xxonp3h0sp0u0hf8hzxo.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744956815/majutech_products/uxrk6xny114nylcbhecz.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744956818/majutech_products/i6cdx1ppjdlh3x0mph2m.png','Acer Predator Helios Neo 16 PHN16-72-56S4 Gaming Laptop | Intel i5-14500HX | NVD RTX4060','normal',4399.0,'<b>Processor Type</b><br>
Core i5<br><br>

<b>Processor Model</b><br>
i5-14500HX<br><br>

<b>Processor Speed</b><br>
2.60 GHz<br><br>

<b>Processor Speed Turbo</b><br>
4.90 GHz<br><br>

<b>Processor Core</b><br>
Tetradeca-core (14 Core)<br><br>

<b>Memory Card Reader</b><br>
Yes<br><br>

<b>Memory Card Supported</b><br>
microSD<br><br>

<b>Total Solid State Drive Capacity</b><br>
1 TB<br><br>

<b>Solid State Drive Interface</b><br>
PCI Express NVMe 4.0<br><br>

<b>Display Screen Type</b><br>
LCD<br><br>

<b>Display Screen Technology</b><br>
ComfyView (Matte), In-plane Switching (IPS) Technology<br><br>

<b>Screen Mode</b><br>
WUXGA<br><br>

<b>Touchscreen</b><br>
No<br><br>

<b>Screen Resolution</b><br>
1920 x 1200<br><br>

<b>Graphics Controller Manufacturer</b><br>
NVIDIA<br><br>

<b>Graphics Controller Model</b><br>
GeForce RTX 4060<br><br>

<b>Graphics Memory Capacity</b><br>
8 GB<br><br>

<b>Graphics Memory Technology</b><br>
GDDR6<br><br>

<b>Graphics Memory Accessibility</b><br>
Dedicated<br><br>

<b>Speakers</b><br>
Yes<br><br>

<b>Number of Speakers</b><br>
2<br><br>

<b>Wireless LAN</b><br>
Yes<br><br>

<b>Wireless LAN Manufacturer</b><br>
Intel<br><br>

<b>Wireless LAN Model</b><br>
Killer Wi-Fi 6E AX1675i<br><br>

<b>Wireless LAN Standard</b><br>
IEEE 802.11ax<br><br>

<b>Bluetooth</b><br>
Yes<br><br>

<b>Microphone</b><br>
Yes<br><br>

<b>Fingerprint Reader</b><br>
No<br><br>

<b>HDMI</b><br>
Yes<br><br>

<b>Total Number of USB Ports</b><br>
5<br><br>

<b>Network RJ-45</b><br>
Yes<br><br>

<b>Audio Line In</b><br>
Yes<br><br>

<b>Audio Line Out</b><br>
Yes<br><br>

<b>Pointing Device Type</b><br>
TouchPad<br><br>

<b>Keyboard Included</b><br>
Yes<br><br>

<b>Keyboard Backlight</b><br>
Yes<br><br>

<b>Battery Chemistry</b><br>
Lithium Ion (Li-Ion)<br><br>

<b>Weight Approximate</b><br>
2.80 kg<br><br>
','<li>16GB RAM</li>
<li>1TB SSD</li>
<li>16" WUXGA 165Hz</li>
<li>RTX4060 8GB GDDR6</li>
<li>Win11</li>
<li>2Y Warranty</li>
',26),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744957929/majutech_products/tlogifwcoev7vi7j5xmf.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744957931/majutech_products/cuuaem45cv00vlsjnobx.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744957934/majutech_products/gowcc1a1tdasc2deqcia.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744957937/majutech_products/zssfvoeduehjnuy3s7av.png','HP AIO 24-cr0029D All in One PC | Intel i3-1315U','normal',2599.0,'<b>Operating System</b><br>
Windows 11 Home Single Language<br><br>

<b>Processors</b><br>
IntelÃÂ® CoreÃ¢ÂÂ¢ i3-1315U (up to 4.5 GHz with IntelÃÂ® Turbo Boost Technology, 10 MB L3 cache, 6 cores, 8 threads)<br><br>

<b>Memory</b><br>
8 GB DDR4-3200 MHz RAM (1 x 8 GB)<br><br>

<b>Memory Slots</b><br>
2 SODIMM<br><br>

<b>Memory Note</b><br>
Transfer rates up to 3200 MT/s.<br><br>

<b>Memory Layout</b><br>
1 x 8 GB<br><br>

<b>Storage</b><br>
512 GB PCIeÃÂ® NVMeÃ¢ÂÂ¢ M.2 SSD<br><br>

<b>Display</b><br>
60.5 cm (23.8") diagonal, FHD (1920 x 1080), IPS, three-sided micro-edge, anti-glare, 250 nits, 99% sRGB<br><br>

<b>Graphics</b><br>
IntelÃÂ® UHD Graphics<br><br>

<b>Screen Size</b><br>
23.8-inch<br><br>

<b>Bezel</b><br>
Three-sided micro-edge<br><br>

<b>Touchscreen</b><br>
No<br><br>

<b>Flicker-Free</b><br>
Yes<br><br>

<b>Screen To Body Ratio</b><br>
98.16%<br><br>

<b>Audio Features</b><br>
Dual 2 W speakers<br><br>

<b>Keyboard</b><br>
HP 510SP White Wireless Keyboard and mouse combo<br><br>

<b>Network Interface</b><br>
Integrated 10/100/1000 GbE LAN<br><br>

<b>Wireless</b><br>
Realtek RTL8852BE Wi-Fi 6 (2x2) and BluetoothÃÂ® 5.3 wireless card (supporting gigabit data rate)<br><br>

<b>I/O Port Location</b><br>
Rear<br><br>

<b>Ports</b><br>
1x USB Type-CÃÂ® 5Gbps signaling rate<br>
2x USB Type-A 5Gbps signaling rate<br>
2x USB 2.0 Type-A<br>
1x Headphone/microphone combo<br>
1x RJ-45<br><br>

<b>Expansion Slots</b><br>
2 M.2 (1 for SSD, 1 for WLAN)<br><br>

<b>Video Connectors</b><br>
1 HDMI-out 1.4<br><br>

<b>Webcam</b><br>
HP True Vision 1080p FHD IR tilt privacy camera with temporal noise reduction and integrated dual array digital microphones<br><br>

<b>Power Supply Type</b><br>
90 W Smart AC power adapter<br><br>

<b>Energy Efficiency Compliance</b><br>
EPEATÃÂ® registered<br><br>

<b>Dimensions Without Stand (W x D x H)</b><br>
54.05 x 18.62 x 40.9 cm<br><br>

<b>Weight</b><br>
5.27 kg<br><br>

<b>Warranty</b><br>
3 Years Onsite Warranty<br>
','  <li>Intel Core i3-1315U Processor</li>
  <li>8GB DDR4 RAM</li>
  <li>512GB SSD</li>
  <li>23.8" FHD (1920 x 1080) IPS Display</li>
  <li>Intel UHD Graphics</li>
  <li>Microsoft Office Home & Student 2021</li>
  <li>Windows 11</li>
  <li>3 Years Warranty</li>
',33),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744960424/majutech_products/lg73oaj8lc8cj3ov4rmq.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960426/majutech_products/fayxx37yxdxvmkoxzgj7.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960428/majutech_products/zccmjyg5inc8ouoiwdtr.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960430/majutech_products/p5ud59ecdmru6fbp9tgj.png','MSI Sword 16 HX B13VFKG-830MY Gaming Laptop | Intel i7-13700HX | NVD RTX4060','normal',3799.0,'<strong>SYSTEM</strong><br>
Windows 11 Home<br><br>

<strong>SERIES</strong><br>
Sword 16 HX<br><br>

<strong>PROCESSOR</strong><br>
IntelÃÂ® CoreÃ¢ÂÂ¢ i7-13700HX<br><br>

<strong>GRAPHIC</strong><br>
NVIDIAÃÂ® GeForce RTXÃ¢ÂÂ¢ 4060 Laptop GPU 8GB DDR6<br><br>

<strong>DISPLAY</strong><br>
16" FHD+ (1920x1200), 144Hz Refresh Rate, IPS-Level<br><br>

<strong>MEMORY</strong><br>
8GB*2, Up to DDR5-5600 (Max 96GB)<br><br>

<strong>STORAGE</strong><br>
1TB*1 NVMe SSD PCIe Gen4<br><br>

<strong>WEBCAM</strong><br>
HD type (30fps@720p), 3D Noise Reduction (3DNR)<br><br>

<strong>KEYBOARD</strong><br>
24-Zone RGB Gaming Keyboard with Copilot Key<br><br>

<strong>COMMUNICATION</strong><br>
IntelÃÂ® Wi-Fi 6E AX211, Bluetooth v5.3<br><br>

<strong>AUDIO</strong><br>
2x 2W Audio Speaker, Nahimic 3 Audio Enhancer, Hi-Res Audio Ready Array Microphone<br><br>

<strong>I/O PORTS</strong><br>
3x Type-A USB3.2 Gen1<br>
1x Type-C (USB3.2 Gen2 / DisplayPortÃ¢ÂÂ¢ / Power Delivery 3.0)<br>
1x HDMIÃ¢ÂÂ¢ 2.1 (8K @ 60Hz / 4K @ 120Hz)<br>
1x Mic-in/Headphone-out Combo Jack<br><br>

<strong>SECURITY</strong><br>
Firmware Trusted Platform Module (fTPM) 2.0, Webcam Shutter, Kensington Lock<br><br>

<strong>BATTERY</strong><br>
4-Cell 65Whrs<br><br>

<strong>AC ADAPTER</strong><br>
200W Adaptor<br><br>

<strong>WEIGHT</strong><br>
2.3kg<br><br>

<strong>DIMENSION (W x D x H)</strong><br>
359 x 266.4 x 21.8-27.7 mm<br><br>

<strong>ACCESSORY</strong><br>
MSI Essential Backpack<br><br>

<strong>COLOR</strong><br>
Cosmos Gray<br><br>

<strong>WARRANTY</strong><br>
2 Years<br>
','<li><strong>16GB RAM</strong></li>
<li><strong>1TB SSD</strong></li>
<li><strong>16" FHD+ (1920x1200) 144Hz</strong></li>
<li><strong>RTX4060 8GB</strong></li>
<li><strong>Windows 11</strong></li>
<li><strong>2 Years Warranty</strong></li>
',40),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744960588/majutech_products/nopbpoeqrfmqxih7scch.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960591/majutech_products/mahnuq9wtjvploaankye.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960594/majutech_products/cbgubnzkkio6holrfidi.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960596/majutech_products/hl1hksoy4qlgw765gjol.png','JBL Flip 7 Bluetooth Speaker','normal',549.0,'<li>Enhanced sound quality with tweaked tweeter and AI Sound Boost DSP system</li>
  <li>14-hour battery life</li>
  <li>Removable carry strap</li>
  <li>Shock-proof and IP68 weather resistant</li>
  <li>New Auracast connectivity system replacing PartyBoost</li>
  <li>Deep bass and balanced audio</li>
','Portable Bluetooth Speaker',99),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744960708/majutech_products/lmswsulnih3khvmkgj6w.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960710/majutech_products/nlr4w1dbqu5jvumrkmy4.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960713/majutech_products/zc3vgoyqkiltocpozxd2.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960715/majutech_products/iqmze6kpyhpbunazcwkm.png','Sony WF-C710N Wireless Noise Cancelling Headphones','normal',299.0,'  <li>Active Noise Cancellation (ANC)</li>
  <li>Long battery life</li>
  <li>Comfortable fit for extended use</li>
  <li>High-quality sound performance</li>','True Wireless Earbuds',99),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744960819/majutech_products/wg8fphplyweygdkivn8b.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960822/majutech_products/oniiuzkt3ksnndegqdjt.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960824/majutech_products/n7vsh1qtvtfaz3r5om60.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960826/majutech_products/wkgqefqovhgdsfm1bazf.png','HyperX Cloud III Gaming Headset','normal',399.0,'  <li>Immersive audio experience</li>
  <li>Durable build quality</li>
  <li>Comfortable design for long gaming sessions</li>
  <li>Compatible with multiple platforms</li>','Wired Gaming Headset',97),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744960946/majutech_products/yvdpolsbkf5gpinb9frz.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960947/majutech_products/sqzroidclxmjkod0q3sx.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960949/majutech_products/dx7brqoqelip5ssg3mpm.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744960950/majutech_products/fettdkuzzuwih97iybzc.png','Sony HT-S400 2.1ch Soundbar','normal',849.0,'  <li>2.1 channel audio system</li>
  <li>Wireless subwoofer for deep bass</li>
  <li>S-Force PRO Front Surround for immersive sound</li>
  <li>Bluetooth connectivity</li>
  <li>HDMI ARC support</li>','Soundbar with Wireless Subwoofer',NULL),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744961071/majutech_products/hy9b9ske29a29b3phsfs.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961073/majutech_products/x39er9anlipz5pen5j11.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961076/majutech_products/baedsbzopyddrxq3dkph.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961079/majutech_products/cno7drdrv6j9kpq0nwzx.png','Google Pixel Buds Pro2','normal',1099.0,'  <li>27% smaller and lighter than previous model</li>
  <li>Wing fins for a stable fit</li>
  <li>Enhanced Active Noise Cancellation with Tensor A1 chip</li>
  <li>11-mm dynamic drivers for superior sound</li>
  <li>IP54 dust and water resistance</li>
  <li>Up to 8 hours of listening with ANC, 30 hours with charging case</li>
  <li>Bluetooth 5.4 with LE Audio support</li>
  <li>Integration with Gemini AI for hands-free voice commands</li>','True Wireless Earbuds',NULL);
INSERT INTO MASTER.PRODUCTS (CATEGORY_ID,IMAGE1,IMAGE2,IMAGE3,IMAGE4,PRODUCT_NAME,STATUS,UNIT_PRICE,DESCRIPTION,SPECIFICATION,QUANTITY) VALUES
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744961224/majutech_products/i9mjaj2enoeui8aojs48.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961226/majutech_products/xrlsrqmyegucn7fatcju.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961228/majutech_products/wlouvhlqhzyrkgxzy3ms.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961230/majutech_products/ut91by03ozarsgoltj4d.png','Huawei FreeArc','normal',529.0,'  <li>High-quality sound performance</li>
  <li>Comfortable and secure fit</li>
  <li>Long battery life</li>
  <li>Active Noise Cancellation</li>','Wireless Earbuds',NULL),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744961334/majutech_products/isqf6tuhabe0oyaycqej.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961336/majutech_products/d1earyun8likvm3dyadx.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961338/majutech_products/zumyz2m7j5hjcsayjik7.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961340/majutech_products/lrptpstqna72d82jahlh.png','HyperX Cloud Earbuds II Gaming Earbuds with Mic','normal',179.0,'  <li>Optimized for handheld mode gaming</li>
  <li>3.5mm plug compatible with various devices</li>
  <li>In-line mic with multi-function button</li>
  <li>Three sizes of ear tips for a comfortable fit</li>
  <li>Carrying case included for portability</li>','Wired Gaming Earbuds',NULL),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744961589/majutech_products/slp7lhawwk8eygt0vcoi.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961591/majutech_products/ckldb7yrmqadvtsherpw.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961594/majutech_products/nmt6aupvehx6hj345vid.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961596/majutech_products/qlncbkse9ffkscjtsell.png','JBL Quantum Stream','normal',499.0,'<li>Dual 14mm electret condenser capsules for high-quality audio</li>
  <li>Two selectable voice pickup patterns: cardioid and omnidirectional</li>
  <li>Universal mounting options for flexible setup</li>
  <li>JBL QuantumENGINE compatibility for customization</li>','USB Microphone',NULL),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744961700/majutech_products/vmgescyqjeyu0ihwjlno.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961703/majutech_products/c483uevqzm7j1oasrzgx.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961706/majutech_products/qo27bahxew9bfh4pzakx.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961708/majutech_products/gvdrtjplolz33dw2rtve.png','IKKO ActiveBuds Wireless Earbuds with ChatGPT','normal',1619.0,'  <li>Built-in ChatGPT integration for AI assistance</li>
  <li>High-fidelity audio performance</li>
  <li>Ergonomic design for comfort</li>
  <li>Touch controls for easy operation</li>
  <li>Long-lasting battery life</li>','True Wireless Earbuds',NULL),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744803631/majutech_products/cagyginktbxmp48upe1a.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744803634/majutech_products/vfda5acnj6bfogs27lle.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744803636/majutech_products/e1debi8smw4f9nm4zxus.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744803638/majutech_products/rw8fj8nv9rcdryg3he4u.png','Acer Aspire Lite 14 AL14-32P-39R3 Laptop | Intel Core i3-N355','normal',1990.9,'<span>
        <b>Processor</b><br>
        <span>Intel® Core™ i3-N305 processor</span><br><br>
        <b>Memory</b><br>
        <span>8 GB of DDR5 SDRAM system memory (upgradable to 32GB DDR5 RAM)</span><br><br>
        <b>Storage</b><br>
        <span>512GB PCIe NVMe SSD</span><br><br>
        <b>Display</b><br>
        <span>14.0"" display with IPS (In-Plane Switching) technology, WUXGA 1920 x 1200, Acer ComfyView™ LED-backlit TFT LCD 16:10 aspect ratio</span><br><br>
        <b>Graphic</b><br>
        <span>Intel® UHD Graphics</span><br><br>
        <b>Webcam</b><br>
        <span>FHD Camera</span><br><br>
        <b>Audio</b><br>
        <span>Speakers</span><br><br>
        <b>Ports</b><br>
        <span>1 x USB Type-C™ port supporting:</span><br>
        <span>USB 3.2 Gen 2 (up to 10 Gbps)</span><br>
        <span>DisplayPort over USB-C</span><br>
        <span>3 x USB Standard-A ports, supporting:</span><br>
        <span>Three ports for USB 3.2 Gen 1</span><br>
        <span>1 x HDMI® 1.4 port with HDCP support</span><br>
        <span>1 x 3.5 mm headphone/speaker jack, supporting headsets with built-in microphone</span><br><br>
        <b>Weight</b><br>
        <span>1.35KG</span><br><br>
        <b>Dimension</b><br>
        <span>314.4 (W) x 220 (D) x 18.95 (H) mm</span>

      </span>','<li>Intel Core i3-N355</li>
<li>8GB RAM</li>
<li>512GB SSD</li>
<li>14" (1920x1200)</li>
<li>Intel UHD Graphics</li>
<li>MS Office H&S 2021</li>
<li>Win11</li>
<li>2Years Warranty</li>',NULL),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744862553/majutech_products/cyaoblrieqdpennteye4.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862556/majutech_products/kgspwxpful3qqdfonbwx.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862559/majutech_products/cb9kxawroxaeommoakop.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862562/majutech_products/gjfjmbvpf8dm2plsbk0l.png','HP Envy x360 14-fa0128AU/fa0129AU 2 in 1 Laptop | AMD Ryzen 5-8640HS','normal',2990.9,'<b>Operating system</b><br>
Windows 11 Home Single Language<br><br>

<b>Processors</b><br>
AMD Ryzenâ¢ 5 8640HS (up to 4.9 GHz max boost clock, 16 MB L3 cache, 6 cores, 12 threads)<br><br>

<b>Memory</b><br>
16 GB LPDDR5-6400 MT/s (onboard)<br><br>

<b>Memory Note</b><br>
Transfer rates up to 6400 MT/s.<br><br>

<b>Storage</b><br>
512 GB PCIeÂ® Gen4 NVMeâ¢ M.2 SSD<br><br>

<b>Display</b><br>
35.6 cm (14") diagonal, 2K (1920 x 1200), multitouch-enabled, IPS, edge-to-edge glass, micro-edge, CorningÂ® GorillaÂ® Glass NBTâ¢, 300 nits, 62.5% sRGB<br><br>

<b>Touchscreen</b><br>
Yes<br><br>

<b>Audio features</b><br>
DTS:XÂ® Ultra; Dual speakers; HP Audio Boost; Poly Studio<br><br>

<b>Stylus</b><br>
HP USB-C Rechargeable MPP2.0 Tilt Natural Silver Pen<br><br>

<b>Pointing device</b><br>
HP Imagepad<br><br>

<b>Keyboard</b><br>
Full-size, backlit, soft grey keyboard<br><br>

<b>Wireless</b><br>
MediaTek Wi-Fi 6E MT7922 (2x2) and BluetoothÂ® 5.3 wireless card<br><br>

<b>Ports</b><br>
2x USB Type-CÂ® 10Gbps signaling rate (USB Power Delivery, DisplayPortâ¢ 1.4a, HP Sleep and Charge);<br>
1x USB Type-A 10Gbps signaling rate (HP Sleep and Charge);<br>
1x USB Type-A 10Gbps signaling rate;<br>
1x HDMI 2.1;<br>
1x headphone/microphone combo<br><br>

<b>Webcam</b><br>
5MP IR camera with temporal noise reduction and integrated dual array digital microphones<br><br>

<b>Power supply type</b><br>
65 W USB Type-CÂ® power adapter<br><br>

<b>Battery life</b><br>
Up to 14 hours and 45 minutes<br><br>

<b>Dimensions without stand (W x D x H)</b><br>
31.33 x 21.89 x 1.69 cm<br><br>

<b>Weight</b><br>
1.39 kg<br>','<li>16GB RAM</li>
 <li>512GB SSD</li>
<li>14" (1920x1200) Touch</li>
 <li>AMD Radeon</li>
  <li>MS Office H&S</li>
  <li>Win11</li>
  <li>2Y Warranty</li>',NULL),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744862957/majutech_products/a0vzqm8sbgbf68ccr58e.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862959/majutech_products/qfiiswjbhgzcissuxkwm.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862962/majutech_products/r8escbghpuso6vlrum30.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862966/majutech_products/foyhxprllyqfiibyaina.png','HP Envy Move AIO 24-cs0006d All in One PC | Intel Core i5-1335U','normal',2590.9,'<b>Processors</b><br>
Intel Core i5-1335U (up to 4.6 GHz with Intel Turbo Boost Technology, 12 MB L3 cache, 10 cores, 12 threads)<br><br>

<b>Memory</b><br>
16 GB LPDDR5-4800 MHz RAM (onboard)<br><br>

<b>Memory Note</b><br>
Transfer rates up to 4800 MT/s.<br><br>

<b>Storage</b><br>
1 TB PCIe NVMe M.2 SSD<br><br>

<b>Display</b><br>
60.5 cm (23.8") diagonal, QHD (2560 x 1440), touch, IPS, three-sided micro-edge, anti-glare, Low Blue Light, 300 nits, 99% sRGB<br><br>

<b>Graphics</b><br>
Intel UHD Graphics<br><br>

<b>Touchscreen</b><br>
Yes<br><br>

<b>Audio features</b><br>
Audio by B&O; Dual 5 W speakers<br><br>

<b>Keyboard</b><br>
HP 720 White Touchpad Integrated Bluetooth Keyboard<br><br>

<b>Wireless</b><br>
Realtek Wi-Fi 6E RTL8852CE (2x2) and Bluetooth 5.3 wireless card<br><br>

<b>I/O Port location</b><br>
Side Ports<br>
1x USB Type-A 10Gbps signaling rate;<br>
1x USB Type-C 10Gbps signaling rate (DisplayPort 1.4a)<br><br>

<b>Expansion slots</b><br>
2x M.2 (1 for SSD, 1 for WLAN)<br><br>

<b>Video connectors</b><br>
1x HDMI-in 1.4b<br><br>

<b>Webcam</b><br>
HP Wide Vision 5 MP IR privacy camera with temporal noise reduction and integrated dual array digital microphones<br><br>

<b>Power supply type</b><br>
90 W Smart AC power adapter<br><br>

<b>Dimensions without stand (W x D x H)</b><br>
55.23 x 14.86 x 36.66 cm<br><br>

<b>Weight</b><br>
4.1 kg','<li>16GB RAM</li>
  <li>1TB SSD</li>
  <li>23.8" (2560x1440) Touch</li>
  <li>Intel UHD</li>
  <li>MS Office H&S</li>
  <li>Win11</li>
  <li>3Y Warranty</li>',NULL),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744862553/majutech_products/cyaoblrieqdpennteye4.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862556/majutech_products/kgspwxpful3qqdfonbwx.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862559/majutech_products/cb9kxawroxaeommoakop.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862562/majutech_products/gjfjmbvpf8dm2plsbk0l.png','HP Envy x360 14-fa0128AU/fa0129AU 2 in 1 Laptop | AMD Ryzen 5-8640HS','normal',2990.9,'<b>Operating system</b><br>
Windows 11 Home Single Language<br><br>

<b>Processors</b><br>
AMD Ryzenâ¢ 5 8640HS (up to 4.9 GHz max boost clock, 16 MB L3 cache, 6 cores, 12 threads)<br><br>

<b>Memory</b><br>
16 GB LPDDR5-6400 MT/s (onboard)<br><br>

<b>Memory Note</b><br>
Transfer rates up to 6400 MT/s.<br><br>

<b>Storage</b><br>
512 GB PCIeÂ® Gen4 NVMeâ¢ M.2 SSD<br><br>

<b>Display</b><br>
35.6 cm (14") diagonal, 2K (1920 x 1200), multitouch-enabled, IPS, edge-to-edge glass, micro-edge, CorningÂ® GorillaÂ® Glass NBTâ¢, 300 nits, 62.5% sRGB<br><br>

<b>Touchscreen</b><br>
Yes<br><br>

<b>Audio features</b><br>
DTS:XÂ® Ultra; Dual speakers; HP Audio Boost; Poly Studio<br><br>

<b>Stylus</b><br>
HP USB-C Rechargeable MPP2.0 Tilt Natural Silver Pen<br><br>

<b>Pointing device</b><br>
HP Imagepad<br><br>

<b>Keyboard</b><br>
Full-size, backlit, soft grey keyboard<br><br>

<b>Wireless</b><br>
MediaTek Wi-Fi 6E MT7922 (2x2) and BluetoothÂ® 5.3 wireless card<br><br>

<b>Ports</b><br>
2x USB Type-CÂ® 10Gbps signaling rate (USB Power Delivery, DisplayPortâ¢ 1.4a, HP Sleep and Charge);<br>
1x USB Type-A 10Gbps signaling rate (HP Sleep and Charge);<br>
1x USB Type-A 10Gbps signaling rate;<br>
1x HDMI 2.1;<br>
1x headphone/microphone combo<br><br>

<b>Webcam</b><br>
5MP IR camera with temporal noise reduction and integrated dual array digital microphones<br><br>

<b>Power supply type</b><br>
65 W USB Type-CÂ® power adapter<br><br>

<b>Battery life</b><br>
Up to 14 hours and 45 minutes<br><br>

<b>Dimensions without stand (W x D x H)</b><br>
31.33 x 21.89 x 1.69 cm<br><br>

<b>Weight</b><br>
1.39 kg<br>','<li>16GB RAM</li>
 <li>512GB SSD</li>
<li>14" (1920x1200) Touch</li>
 <li>AMD Radeon</li>
  <li>MS Office H&S</li>
  <li>Win11</li>
  <li>2Y Warranty</li>',NULL),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744862959/majutech_products/qfiiswjbhgzcissuxkwm.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862957/majutech_products/a0vzqm8sbgbf68ccr58e.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862962/majutech_products/r8escbghpuso6vlrum30.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744862966/majutech_products/foyhxprllyqfiibyaina.png','HP Envy Move AIO 24-cs0006d All in One PC | Intel Core i5-1335U','normal',2590.9,'<b>Processors</b><br>
Intel Core i5-1335U (up to 4.6 GHz with Intel Turbo Boost Technology, 12 MB L3 cache, 10 cores, 12 threads)<br><br>

<b>Memory</b><br>
16 GB LPDDR5-4800 MHz RAM (onboard)<br><br>

<b>Memory Note</b><br>
Transfer rates up to 4800 MT/s.<br><br>

<b>Storage</b><br>
1 TB PCIe NVMe M.2 SSD<br><br>

<b>Display</b><br>
60.5 cm (23.8") diagonal, QHD (2560 x 1440), touch, IPS, three-sided micro-edge, anti-glare, Low Blue Light, 300 nits, 99% sRGB<br><br>

<b>Graphics</b><br>
Intel UHD Graphics<br><br>

<b>Touchscreen</b><br>
Yes<br><br>

<b>Audio features</b><br>
Audio by B&O; Dual 5 W speakers<br><br>

<b>Keyboard</b><br>
HP 720 White Touchpad Integrated Bluetooth Keyboard<br><br>

<b>Wireless</b><br>
Realtek Wi-Fi 6E RTL8852CE (2x2) and Bluetooth 5.3 wireless card<br><br>

<b>I/O Port location</b><br>
Side Ports<br>
1x USB Type-A 10Gbps signaling rate;<br>
1x USB Type-C 10Gbps signaling rate (DisplayPort 1.4a)<br><br>

<b>Expansion slots</b><br>
2x M.2 (1 for SSD, 1 for WLAN)<br><br>

<b>Video connectors</b><br>
1x HDMI-in 1.4b<br><br>

<b>Webcam</b><br>
HP Wide Vision 5 MP IR privacy camera with temporal noise reduction and integrated dual array digital microphones<br><br>

<b>Power supply type</b><br>
90 W Smart AC power adapter<br><br>

<b>Dimensions without stand (W x D x H)</b><br>
55.23 x 14.86 x 36.66 cm<br><br>

<b>Weight</b><br>
4.1 kg','<li>16GB RAM</li>
  <li>1TB SSD</li>
  <li>23.8" (2560x1440) Touch</li>
  <li>Intel UHD</li>
  <li>MS Office H&S</li>
  <li>Win11</li>
  <li>3Y Warranty</li>',NULL),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744863134/majutech_products/hs0a7glmt5hm02h42uns.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863136/majutech_products/r5g8x1lpsozy6mirtpbn.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863139/majutech_products/aydn6xgatg3mxq5jdmtt.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863142/majutech_products/xysil8xlqyvpvdhl8dbc.png','ASUS Vivobook 14 Flip TP3407S-AQL028WS 2 in 1 Laptop | Intel Core Ultra 7-258V','normal',3299.99,'<b>Operating System</b><br>
Windows 11 Home<br>
Copilot+ PC experiences are coming. Requires free updates available starting late November 2024. Timing varies by device and region.<br><br>

<b>Processor</b><br>
Intel Core Ultra 7 Processor 258V 32GB 2.2 GHz (12MB Cache, up to 4.8 GHz, 8 cores, 8 Threads); Intel AI Boost NPU up to 47TOPS<br><br>

<b>Graphics</b><br>
Intel Arc Graphics<br><br>

<b>Neural Processor</b><br>
Intel AI Boost NPU up to 47TOPS<br><br>

<b>Display</b><br>
14.0-inch, WUXGA (1920 x 1200) OLED 16:10 aspect ratio, 0.2ms response time, 60Hz refresh rate, 400nits, 500nits HDR peak brightness, 100% DCI-P3 color gamut, 1,000,000:1, VESA CERTIFIED Display HDR True Black 500, 1.07 billion colors, Glossy display, 70% less harmful blue light, TUV Rheinland-certified, Touch screen, (Screen-to-body ratio)85%, With stylus support<br><br>

<b>Memory</b><br>
32GB LPDDR5X Memory on Package<br>
Max Total system memory up to:32GB<br><br>

<b>Storage</b><br>
1TB M.2 NVMe PCIe 4.0 SSD<br><br>

<b>Expansion Slots (includes used)</b><br>
1x M.2 2280 PCIe 4.0x4<br><br>

<b>I/O Ports</b><br>
1x USB 3.2 Gen 1 Type-A (data speed up to 5Gbps)<br>
1x USB 3.2 Gen 2 Type-C with support for display / power delivery (data speed up to 20Gbps)<br>
1x Thunderbolt 4 with support for display / power delivery (data speed up to 40Gbps)<br>
1x HDMI 2.1 TMDS<br>
1x 3.5mm Combo Audio Jack<br>
Micro SD card reader<br><br>

<b>Camera</b><br>
1080p FHD camera<br>
With privacy shutter<br><br>

<b>Audio</b><br>
Smart Amp Technology<br>
Built-in speaker<br>
Built-in array microphone<br><br>

<b>Network and Communication</b><br>
Wi-Fi 7(802.11be) (Tri-band)2*2 + Bluetooth 5.4 Wireless Card (*Bluetooth version may change with OS version different.)<br><br>

<b>Power Supply</b><br>
TYPE-C, 65W AC Adapter, Output: 20V DC, 3.25A, 65W, Input: 100-240V AC 50/60GHz universal<br><br>

<b>Weight</b><br>
1.57 kg (3.46 lbs)<br><br>

<b>Dimensions (W x D x H)</b><br>
31.26 x 22.09 x 1.69 ~ 1.71 cm (12.31" x 8.70" x 0.67" ~ 0.67")','<li>32GB RAM</li>
<li>1TB SSD</li>
<li>14" (1920x1200) OLED Touch</li>
<li>Intel Arc Graphics</li>
<li>MS Office Home</li>
<li>Win11</li>
<li>2Y Warranty</li>',NULL);
INSERT INTO MASTER.PRODUCTS (CATEGORY_ID,IMAGE1,IMAGE2,IMAGE3,IMAGE4,PRODUCT_NAME,STATUS,UNIT_PRICE,DESCRIPTION,SPECIFICATION,QUANTITY) VALUES
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744863315/majutech_products/twkzyiyr30tllvfys4ws.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863318/majutech_products/xl1ojjkb3ixud2rjikdg.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863321/majutech_products/n0vcdusdavcsyyu4xgjq.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863324/majutech_products/iqjmzcqyj5znsqwdlnjl.png','Lenovo Yoga 9 14IMH9 (83AC005DMJ) 2 In 1 Laptop | Intel Core Ultra 7 155H','normal',2599.99,'<b>Processor</b><br>
Intel Core Ultra 7 155H, 16C (6P + 8E + 2LPE) / 22T, Max Turbo up to 4.8GHz, 24MB<br><br>

<b>AI PC Category</b><br>
AI PC<br><br>

<b>NPU</b><br>
Integrated Intel AI Boost, up to 11 TOPS<br><br>

<b>Graphics</b><br>
Integrated Intel Arc Graphics<br><br>

<b>Display</b><br>
14" 4K WQUXGA (3840x2400) OLED 400nits Glossy / Anti-fingerprint, 100% DCI-P3, 60Hz, Eyesafe, Dolby Vision, DisplayHDR True Black 500, Glass, Touch<br><br>

<b>Touchscreen</b><br>
OGM, 10-point Multi-touch<br><br>

<b>Chipset</b><br>
Intel SoC Platform<br><br>

<b>Memory</b><br>
32GB Soldered LPDDR5x-7467<br><br>

<b>Memory Slots</b><br>
Memory soldered to systemboard, no slots, dual-channel<br><br>

<b>Max Memory</b><br>
32GB soldered memory, not upgradable<br><br>

<b>Storage</b><br>
1TB SSD M.2 2242 PCIe 4.0x4 NVMe<br><br>

<b>Storage Support</b><br>
One drive, up to 1TB M.2 2242 SSD<br><br>

<b>Storage Slot</b><br>
One M.2 2242 PCIe 4.0 x4 slot<br><br>

<b>Card Reader</b><br>
None<br><br>

<b>Audio Chip</b><br>
High Definition (HD) Audio, Realtek ALC3306 codec<br><br>

<b>Speakers</b><br>
4 stereo speakers, 2W x2 (woofers on the side), 2W x2 (front-facing tweeters on hinge bar), optimized with Dolby Atmos, Smart Amplifier (AMP), sound by Bowers & Wilkins<br><br>

<b>Camera</b><br>
5.0MP + IR with Privacy Shutter<br><br>

<b>Microphone</b><br>
2x, Array<br><br>

<b>Dimensions (WxDxH)</b><br>
316 x 220 x 15.9 mm (12.44 x 8.66 x 0.63 inches)<br><br>

<b>Weight</b><br>
Starting at 1.32 kg (2.91 lbs)','<li>32GB RAM</li>
<li>1TB SSD</li>
<li>14" (3840x2400) Touch</li>
<li>Intel Arc Graphics</li>
<li>MS Office H&S 2021</li>
<li>Win11</li>
<li>2Y Warranty</li>',NULL),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744863134/majutech_products/hs0a7glmt5hm02h42uns.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863136/majutech_products/r5g8x1lpsozy6mirtpbn.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863139/majutech_products/aydn6xgatg3mxq5jdmtt.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863142/majutech_products/xysil8xlqyvpvdhl8dbc.png','ASUS Vivobook 14 Flip TP3407S-AQL028WS 2 in 1 Laptop | Intel Core Ultra 7-258V','normal',3299.99,'<b>Operating System</b><br>
Windows 11 Home<br>
Copilot+ PC experiences are coming. Requires free updates available starting late November 2024. Timing varies by device and region.<br><br>

<b>Processor</b><br>
Intel Core Ultra 7 Processor 258V 32GB 2.2 GHz (12MB Cache, up to 4.8 GHz, 8 cores, 8 Threads); Intel AI Boost NPU up to 47TOPS<br><br>

<b>Graphics</b><br>
Intel Arc Graphics<br><br>

<b>Neural Processor</b><br>
Intel AI Boost NPU up to 47TOPS<br><br>

<b>Display</b><br>
14.0-inch, WUXGA (1920 x 1200) OLED 16:10 aspect ratio, 0.2ms response time, 60Hz refresh rate, 400nits, 500nits HDR peak brightness, 100% DCI-P3 color gamut, 1,000,000:1, VESA CERTIFIED Display HDR True Black 500, 1.07 billion colors, Glossy display, 70% less harmful blue light, TUV Rheinland-certified, Touch screen, (Screen-to-body ratio)85%, With stylus support<br><br>

<b>Memory</b><br>
32GB LPDDR5X Memory on Package<br>
Max Total system memory up to:32GB<br><br>

<b>Storage</b><br>
1TB M.2 NVMe PCIe 4.0 SSD<br><br>

<b>Expansion Slots (includes used)</b><br>
1x M.2 2280 PCIe 4.0x4<br><br>

<b>I/O Ports</b><br>
1x USB 3.2 Gen 1 Type-A (data speed up to 5Gbps)<br>
1x USB 3.2 Gen 2 Type-C with support for display / power delivery (data speed up to 20Gbps)<br>
1x Thunderbolt 4 with support for display / power delivery (data speed up to 40Gbps)<br>
1x HDMI 2.1 TMDS<br>
1x 3.5mm Combo Audio Jack<br>
Micro SD card reader<br><br>

<b>Camera</b><br>
1080p FHD camera<br>
With privacy shutter<br><br>

<b>Audio</b><br>
Smart Amp Technology<br>
Built-in speaker<br>
Built-in array microphone<br><br>

<b>Network and Communication</b><br>
Wi-Fi 7(802.11be) (Tri-band)2*2 + Bluetooth 5.4 Wireless Card (*Bluetooth version may change with OS version different.)<br><br>

<b>Power Supply</b><br>
TYPE-C, 65W AC Adapter, Output: 20V DC, 3.25A, 65W, Input: 100-240V AC 50/60GHz universal<br><br>

<b>Weight</b><br>
1.57 kg (3.46 lbs)<br><br>

<b>Dimensions (W x D x H)</b><br>
31.26 x 22.09 x 1.69 ~ 1.71 cm (12.31" x 8.70" x 0.67" ~ 0.67")','<li>32GB RAM</li>
<li>1TB SSD</li>
<li>14" (1920x1200) OLED Touch</li>
<li>Intel Arc Graphics</li>
<li>MS Office Home</li>
<li>Win11</li>
<li>2Y Warranty</li>',NULL),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744863315/majutech_products/twkzyiyr30tllvfys4ws.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863318/majutech_products/xl1ojjkb3ixud2rjikdg.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863321/majutech_products/n0vcdusdavcsyyu4xgjq.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744863324/majutech_products/iqjmzcqyj5znsqwdlnjl.png','Lenovo Yoga 9 14IMH9 (83AC005DMJ) 2 In 1 Laptop | Intel Core Ultra 7 155H','normal',2599.99,'<b>Processor</b><br>
Intel Core Ultra 7 155H, 16C (6P + 8E + 2LPE) / 22T, Max Turbo up to 4.8GHz, 24MB<br><br>

<b>AI PC Category</b><br>
AI PC<br><br>

<b>NPU</b><br>
Integrated Intel AI Boost, up to 11 TOPS<br><br>

<b>Graphics</b><br>
Integrated Intel Arc Graphics<br><br>

<b>Display</b><br>
14" 4K WQUXGA (3840x2400) OLED 400nits Glossy / Anti-fingerprint, 100% DCI-P3, 60Hz, Eyesafe, Dolby Vision, DisplayHDR True Black 500, Glass, Touch<br><br>

<b>Touchscreen</b><br>
OGM, 10-point Multi-touch<br><br>

<b>Chipset</b><br>
Intel SoC Platform<br><br>

<b>Memory</b><br>
32GB Soldered LPDDR5x-7467<br><br>

<b>Memory Slots</b><br>
Memory soldered to systemboard, no slots, dual-channel<br><br>

<b>Max Memory</b><br>
32GB soldered memory, not upgradable<br><br>

<b>Storage</b><br>
1TB SSD M.2 2242 PCIe 4.0x4 NVMe<br><br>

<b>Storage Support</b><br>
One drive, up to 1TB M.2 2242 SSD<br><br>

<b>Storage Slot</b><br>
One M.2 2242 PCIe 4.0 x4 slot<br><br>

<b>Card Reader</b><br>
None<br><br>

<b>Audio Chip</b><br>
High Definition (HD) Audio, Realtek ALC3306 codec<br><br>

<b>Speakers</b><br>
4 stereo speakers, 2W x2 (woofers on the side), 2W x2 (front-facing tweeters on hinge bar), optimized with Dolby Atmos, Smart Amplifier (AMP), sound by Bowers & Wilkins<br><br>

<b>Camera</b><br>
5.0MP + IR with Privacy Shutter<br><br>

<b>Microphone</b><br>
2x, Array<br><br>

<b>Dimensions (WxDxH)</b><br>
316 x 220 x 15.9 mm (12.44 x 8.66 x 0.63 inches)<br><br>

<b>Weight</b><br>
Starting at 1.32 kg (2.91 lbs)','<li>32GB RAM</li>
<li>1TB SSD</li>
<li>14" (3840x2400) Touch</li>
<li>Intel Arc Graphics</li>
<li>MS Office H&S 2021</li>
<li>Win11</li>
<li>2Y Warranty</li>',NULL),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744961789/majutech_products/mld8tbtoz0ome1nros4b.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961791/majutech_products/okalvndqni51jmkx9bzj.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961794/majutech_products/nrarls6s2x3vhxvs0xvz.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744961796/majutech_products/ms8meddb2cni7gs0krks.png','HyperX Cloud Stinger Core Wireless Gaming Headset','normal',279.0,'  <li>Lightweight design for comfort</li>
  <li>Immersive in-game audio</li>
  <li>Adjustable steel sliders for durability</li>
  <li>Noise-cancelling microphone</li>
  <li>Up to 17 hours of battery life</li>
  <li>2.4GHz wireless connection for low-latency gaming</li>','Wireless Gaming Headset',NULL),
	 (4,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744962078/majutech_products/jpfybohifl5qpgru8h6b.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744962080/majutech_products/gyzzhya2cmyxxo0fucpo.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744962082/majutech_products/fpqbl61dsl9s9srcjdb8.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744962084/majutech_products/mmcrtwvn0vkqrzindoxd.png','Mophie Essentials 60W USB-C to C Braided Cable','normal',59.0,'<b>Type</b><br>
USB-C to USB-C<br><br>

<b>Power Support</b><br>
Up to 60W (USB PD)<br><br>

<b>Length</b><br>
1.5 meters<br><br>

<b>Features</b><br>
Durable braided exterior<br>
Fast charging support<br>
Sync & charge compatible<br>
','',NULL),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744962192/majutech_products/gcsbhpnpb81v5wicd8ds.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744962194/majutech_products/ydfprqnacgtdafno9py2.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744962197/majutech_products/aili6xsmgep5prvufzkx.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744962199/majutech_products/qmunwwk9ahlqbrjmpmlp.png','Innostyle PowerGo Mini with Built-in Cable Power Bank','normal',99.0,'<b>Battery Capacity</b><br>
10,000mAh<br><br>

<b>Output Ports</b><br>
â¢ USB-C (with built-in cable)<br>
â¢ USB-A<br><br>

<b>Charging Power</b><br>
â¢ Up to 20W PD<br><br>

<b>Features</b><br>
â¢ Compact and pocket-sized<br>
â¢ LED battery indicator<br>
â¢ Includes USB-C cable<br>
','',NULL),
	 (4,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744962976/majutech_products/yxzliiy1e6rob0vo6lmg.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744962979/majutech_products/lgpqaugxevevzvq1kbsf.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744962981/majutech_products/yv5qfpth4kjcmxigyqml.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744962984/majutech_products/ctnwyltvuhbloctrwb2k.png','Innostyle PowerMag Switch 2-in-1 Magnetic Wireless Power Bank','normal',159.0,'<b>Battery Capacity</b><br>
10,000mAh<br><br>

<b>Charging Options</b><br>
â¢ Magnetic Wireless Charging<br>
â¢ USB-C PD 20W<br><br>

<b>Special Feature</b><br>
Detachable Kickstand for Hands-Free Use<br><br>

<b>Compatibility</b><br>
MagSafe-supported iPhones<br>
','',NULL),
	 (4,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744963261/majutech_products/cuuiheedcm8gyvrg8eaj.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963263/majutech_products/sxyt7yqubddh8vhdvk1h.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963266/majutech_products/srfka55lgjkqcvonttuy.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963268/majutech_products/h5oxui4ccsihzmtp8wrl.png','Beats Powerbeats Pro2','normal',1049.0,'<b>Type</b><br>
True Wireless Earbuds<br><br>

<b>Audio</b><br>
â¢ High-performance with powerful bass<br>
â¢ Apple H1 chip<br><br>

<b>Battery Life</b><br>
â¢ Up to 9 hours (earbuds)<br>
â¢ Over 24 hours with charging case<br><br>

<b>Features</b><br>
â¢ Sweat & water resistant<br>
â¢ Secure-fit ear hooks<br>
â¢ Voice assistant support<br>
','',NULL),
	 (4,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744963348/majutech_products/ototcalsbqm1qmjvq8er.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963350/majutech_products/c3kl6vm5tudppqe9vreq.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963352/majutech_products/pcgodiowdlfrquduhkf6.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963354/majutech_products/itihsctvkxiw44l9lhvj.png','Samsung Single Pad Wireless Charger','normal',103.0,'<b>Type</b><br>
Qi Wireless Charging Pad<br><br>

<b>Output Power</b><br>
Up to 15W (fast charging for Samsung devices)<br><br>

<b>Features</b><br>
â¢ Compact pad design<br>
â¢ Compatible with other Qi-enabled phones<br>
â¢ LED indicator<br>
','',NULL),
	 (4,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744963478/majutech_products/mhefpbnn2tmmp1wy6otb.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963480/majutech_products/yahxnchvvtjhk7l6w7ou.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963483/majutech_products/jjrnw1w254txzsglxxk6.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963485/majutech_products/iiemsnn40cfthrdz8g3h.png','Samsung Car Charger','normal',129.0,'<b>Ports</b><br>
Dual Port: USB-A + USB-C<br><br>

<b>Output Power</b><br>
Up to 45W total<br><br>

<b>Features</b><br>
â¢ Adaptive fast charging<br>
â¢ Compatible with Samsung Super Fast Charging<br>
','',NULL);
INSERT INTO MASTER.PRODUCTS (CATEGORY_ID,IMAGE1,IMAGE2,IMAGE3,IMAGE4,PRODUCT_NAME,STATUS,UNIT_PRICE,DESCRIPTION,SPECIFICATION,QUANTITY) VALUES
	 (4,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744963553/majutech_products/up37e4wetmoi1jn3ujp0.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963555/majutech_products/vyvdf6we8vequ81nxod6.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963557/majutech_products/qdsbflbhknskgxud6cou.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963559/majutech_products/woypex29kxyox2ond6j7.png','Verbatim Charge-n-Travel Diamond GaN 85W Charger','normal',279.0,'<b>Type</b><br>
GaN Wall Charger<br><br>

<b>Ports</b><br>
â¢ 2 x USB-C<br>
â¢ 1 x USB-A<br><br>

<b>Power Output</b><br>
85W (max)<br><br>

<b>Features</b><br>
â¢ Foldable plug<br>
â¢ Universal voltage support (100-240V)<br>
â¢ Travel-friendly<br>
','',NULL),
	 (4,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744963699/majutech_products/ztpcrecpap2dt65xipp4.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963701/majutech_products/bmhc7eryexbdnjnlgjob.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963703/majutech_products/arje10yknluobfc6yoml.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744963705/majutech_products/hfjqbgab5kyfhq1ezlzx.png','Mazer MagFold05 3-in-1 Wireless Foldable Charging Station Type','normal',369.0,'<b>Type</b><br>
3-in-1 Wireless Charger<br><br>

<b>Charging Support</b><br>
â¢ iPhone (MagSafe)<br>
â¢ Apple Watch<br>
â¢ AirPods<br><br>

<b>Features</b><br>
â¢ Foldable and travel-ready<br>
â¢ Magnetic phone holder<br>
â¢ USB-C powered<br>
','',NULL),
	 (4,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744964030/majutech_products/iqxq124o2lmo4xrjczbq.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744964032/majutech_products/nbjhhnhlp7aha1kcww7l.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744964034/majutech_products/zwsov9niyloyj0o2qppk.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744964036/majutech_products/murrf10vgqvd8scxqf7c.png','Innostyle PowerMag Slim Magnetic Wireless Power Bank','normal',139.0,'<b>Battery Capacity</b><br>
5000mAh<br><br>

<b>Charging Options</b><br>
â¢ MagSafe Magnetic Wireless Charging (15W max)<br>
â¢ USB-C PD 20W<br><br>

<b>Compatibility</b><br>
MagSafe-compatible iPhones (12 and above)<br><br>

<b>Features</b><br>
â¢ Slim and travel-friendly<br>
â¢ Strong magnetic hold<br>
','',NULL),
	 (4,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744964294/majutech_products/nb0ebhqkycoqo2bmcmk6.jpg','https://res.cloudinary.com/dx91axmwl/image/upload/v1744964296/majutech_products/l4diqd1py79rqsivncjc.jpg','https://res.cloudinary.com/dx91axmwl/image/upload/v1744964297/majutech_products/fyq1pztrjtxhjxkgdfes.jpg','https://res.cloudinary.com/dx91axmwl/image/upload/v1744964299/majutech_products/raigb1pxo0fkldfy9vy3.jpg','Verbatim GNC-100 GaN 100W 4-Port Charger','normal',309.0,'<b>Type</b><br>
4-Port Wall Charger (GaN)<br><br>

<b>Ports</b><br>
â¢ 3 x USB-C<br>
â¢ 1 x USB-A<br><br>

<b>Power Output</b><br>
Up to 100W<br><br>

<b>Features</b><br>
â¢ Compact GaN design<br>
â¢ Intelligent power distribution<br>
â¢ Great for charging multiple devices<br>
','',NULL),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744965006/majutech_products/vniqfuizivkxkylkhfnx.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965008/majutech_products/vpziscczq05os8bj32wn.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965011/majutech_products/h5mwj9m6uobwgjeiddhy.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965013/majutech_products/lprarnnsoagqv8b7kmqj.png','HUAWEI MATE XT ULTIMATE DESIGN','normal',14999.0,'<b>Processor</b><br>
Kirin 9010 Octa-core Processor<br><br>

<b>Memory</b><br>
16GB RAM<br><br>

<b>Storage</b><br>
512GB / 1TB Storage<br><br>

<b>Display</b><br>
10.2" OLED Foldable Display (Tri-Fold)<br>
Resolution: up to 2480 x 2200<br>
Three Modes: 6.4", 7.9", 10.2"<br><br>

<b>Graphics</b><br>
Mali-G78 GPU<br><br>

<b>Camera</b><br>
Triple Rear Camera:<br>
â¢ 50MP Main<br>
â¢ 12MP Periscope Telephoto<br>
â¢ 12MP Ultrawide<br>
Front: 16MP<br><br>

<b>Battery</b><br>
5600mAh<br>
66W Wired + 50W Wireless Charging<br><br>

<b>OS</b><br>
HarmonyOS 4.0<br><br>

<b>Build</b><br>
Premium leather back, aerospace-grade fiber<br><br>

<b>Weight</b><br>
240g<br>
','',NULL),
	 (3,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744965380/majutech_products/ssnm07mr6kmjmo7a4eg6.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965383/majutech_products/timtpro13k82vzblskj9.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965385/majutech_products/bhanngqj9uvq3zcwswxb.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965388/majutech_products/bctqoqmlqtvmuopuhdze.png','GOOGLE PIXEL 9 PRO XL','normal',5699.0,'<b>Processor</b><br>
Google Tensor G4<br><br>

<b>Memory</b><br>
16GB RAM<br><br>

<b>Storage</b><br>
128GB / 256GB / 512GB / 1TB<br><br>

<b>Display</b><br>
6.8" LTPO OLED, 120Hz refresh rate<br><br>

<b>Graphics</b><br>
Immortalis-G715<br><br>

<b>Camera</b><br>
â¢ Rear: Triple â 50MP (Main) + 48MP (Ultra-wide) + 48MP (5x Telephoto)<br>
â¢ Front: 42MP<br><br>

<b>Battery</b><br>
5,000mAh<br>
30W wired, 23W wireless charging<br><br>

<b>OS</b><br>
Android 14, upgradable to Android 15<br><br>

<b>Weight</b><br>
~213g<br><br>

<b>Dimensions</b><br>
~162.9 x 76.6 x 8.9 mm<br>
','',NULL),
	 (3,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744965531/majutech_products/qilrstylomdkvkllsykr.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965533/majutech_products/irizlaswbd5vif0mcmaq.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965536/majutech_products/huthser2qrudwld9whcv.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965539/majutech_products/o3ym5hl0yh0m2t4mmxth.png','VIVO V50 5G','normal',2399.0,'<b>Processor</b><br>
Qualcomm Snapdragon 7 Gen 3<br><br>

<b>Memory</b><br>
8GB RAM<br><br>

<b>Storage</b><br>
256GB<br><br>

<b>Display</b><br>
6.67" AMOLED, 120Hz refresh rate<br><br>

<b>Graphics</b><br>
Adreno 720<br><br>

<b>Camera</b><br>
â¢ Rear: Dual â 64MP (Main) + 2MP (Depth)<br>
â¢ Front: 16MP<br><br>

<b>Battery</b><br>
5,000mAh<br>
44W wired charging<br><br>

<b>OS</b><br>
Funtouch OS 14 (based on Android 14)<br><br>

<b>Weight</b><br>
~185g<br><br>

<b>Dimensions</b><br>
~164.1 x 74.8 x 7.8 mm<br>
','',NULL),
	 (3,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744965609/majutech_products/blx4oxbw1yj78pd4ug5t.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965611/majutech_products/rnxpeirz8rrywffemzbu.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965614/majutech_products/qx0ydf9grntuyqkbnzvb.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744965616/majutech_products/efofs4osa8vryfgepchy.png','APPLE IPHONE 16 PRO MAX','normal',5299.0,'<b>Processor</b><br>
Apple A18 Pro Chip<br><br>

<b>Memory</b><br>
8GB RAM<br><br>

<b>Storage</b><br>
Up to 1TB<br><br>

<b>Display</b><br>
6.9" Super Retina XDR OLED<br>
2778 x 1284 resolution, ProMotion 120Hz<br><br>

<b>Graphics</b><br>
Apple GPU (6-core)<br><br>

<b>Camera</b><br>
Triple Rear Camera:<br>
â¢ 48MP Main<br>
â¢ 12MP Ultrawide<br>
â¢ 12MP Telephoto (5x optical zoom)<br>
Front: 12MP<br><br>

<b>Battery</b><br>
Approx. 4400mAh equivalent<br>
MagSafe + USB-C Charging<br><br>

<b>OS</b><br>
iOS 18.1<br><br>

<b>Build</b><br>
Titanium Frame, Ceramic Shield<br><br>

<b>Weight</b><br>
225g<br>
','',NULL),
	 (3,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744967240/majutech_products/vqqo4dmhzlruhkv9qsto.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967243/majutech_products/yro9skg7uwuexslo2wlf.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967245/majutech_products/ngbafnv0lpdbgq7bvnku.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967248/majutech_products/ubexbnwp9at6byzozopz.png','ASUS ROG PHONE 9 5G','normal',3777.0,'<b>Processor</b><br>
Qualcomm Snapdragon 8 Gen 3<br><br>

<b>Memory</b><br>
16GB LPDDR5X RAM<br><br>

<b>Storage</b><br>
512GB UFS 4.0<br><br>

<b>Display</b><br>
6.78" AMOLED, 165Hz refresh rate<br><br>

<b>Graphics</b><br>
Adreno 750<br><br>

<b>Camera</b><br>
â¢ Rear: Triple â 50MP (Main) + 13MP (Ultra-wide) + 5MP (Macro)<br>
â¢ Front: 32MP<br><br>

<b>Battery</b><br>
6,000mAh<br>
65W wired charging<br><br>

<b>OS</b><br>
Android 14, ROG UI<br><br>

<b>Weight</b><br>
~239g<br><br>

<b>Dimensions</b><br>
~173 x 77 x 10.3 mm<br>
','',NULL),
	 (3,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744967363/majutech_products/m4dwddcyrdzvzccky3wj.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967365/majutech_products/gg0zlmzxx9ncyt77jkji.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967367/majutech_products/zpe7kclrkio2lbnyjtts.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967370/majutech_products/gufkjmpkqxpcpqcftwcn.png','HONOR MAGIC V3','normal',4919.0,'<b>Processor</b><br>
Snapdragon 8 Gen 3<br><br>

<b>Memory</b><br>
12GB RAM<br><br>

<b>Storage</b><br>
512GB Storage<br><br>

<b>Display</b><br>
â¢ Outer: 6.43" OLED, 120Hz<br>
â¢ Inner: 7.92" Foldable OLED, 120Hz<br><br>

<b>Graphics</b><br>
Adreno 750 GPU<br><br>

<b>Camera</b><br>
Triple Rear Camera:<br>
â¢ 50MP Main<br>
â¢ 50MP Periscope<br>
â¢ 40MP Ultrawide<br>
Front: 16MP<br><br>

<b>Battery</b><br>
5150mAh<br>
66W Wired Charging<br><br>

<b>OS</b><br>
MagicOS 8 (Android 14)<br><br>

<b>Weight</b><br>
~231g<br>
','',NULL);
INSERT INTO MASTER.PRODUCTS (CATEGORY_ID,IMAGE1,IMAGE2,IMAGE3,IMAGE4,PRODUCT_NAME,STATUS,UNIT_PRICE,DESCRIPTION,SPECIFICATION,QUANTITY) VALUES
	 (3,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744967454/majutech_products/csvrjhh1wzlothim1kgg.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967456/majutech_products/my50oqpb3dzwbq0mhltm.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967458/majutech_products/k9qcsik9tunlrxe2eche.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967460/majutech_products/obwu2bejjabrnpo2iupk.png','OPPO FIND X8 5G','normal',3699.0,'<b>Processor</b><br>
Snapdragon 8 Gen 3 Elite<br><br>

<b>Memory</b><br>
16GB RAM<br><br>

<b>Storage</b><br>
Up to 1TB<br><br>

<b>Display</b><br>
6.82" AMOLED, 120Hz<br>
Resolution: 3168 Ã 1440<br><br>

<b>Graphics</b><br>
Adreno 750 GPU<br><br>

<b>Camera</b><br>
Quad Rear Camera (All 50MP sensors):<br>
â¢ Main<br>
â¢ Ultra-wide<br>
â¢ 3x Zoom<br>
â¢ 6x Periscope<br>
Front: 32MP<br><br>

<b>Battery</b><br>
6100mAh<br>
100W Wired / 50W Wireless<br><br>

<b>Build</b><br>
Ultra-thin at 8.78mm<br><br>

<b>Weight</b><br>
~210g<br>
','',NULL),
	 (3,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744967545/majutech_products/g1rdufdjh9ce0jsv7xys.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967547/majutech_products/kiptkcwmkfqgtbbekgnb.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967549/majutech_products/l9nbwtqx4myseafwnqgz.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967551/majutech_products/j37kxcpgz9z5wrgearpy.png','SAMSUNG GALAXY S24 FE 5G','normal',2499.0,'<b>Processor</b><br>
Exynos 2400e<br><br>

<b>Memory</b><br>
8GB RAM<br><br>

<b>Storage</b><br>
128GB / 256GB / 512GB<br><br>

<b>Display</b><br>
6.7" Dynamic AMOLED 2X<br>
120Hz, FHD+<br><br>

<b>Graphics</b><br>
Xclipse 940<br><br>

<b>Camera</b><br>
Triple Rear Camera:<br>
â¢ 50MP Main<br>
â¢ 8MP Telephoto (3x zoom)<br>
â¢ 12MP Ultrawide<br>
Front: 10MP<br><br>

<b>Battery</b><br>
4700mAh<br>
25W Wired, 15W Wireless<br><br>

<b>OS</b><br>
Android 14 (One UI 6.1)<br><br>

<b>Weight</b><br>
~209g<br>
','',NULL),
	 (3,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744967613/majutech_products/ior9niim96vly9tvz4y4.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967616/majutech_products/ochwegzcpeu9geri9oiz.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967618/majutech_products/qhvqg1zacbihb5auxale.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967621/majutech_products/up5e9wzhssnyvwjkqhax.png','NONTHING PHONE (2A) PLUS 5G','normal',1900.0,'<b>Processor</b><br>
MediaTek Dimensity 7200 Pro<br><br>

<b>Memory</b><br>
12GB RAM<br><br>

<b>Storage</b><br>
256GB<br><br>

<b>Display</b><br>
6.7" AMOLED, 120Hz refresh rate<br><br>

<b>Graphics</b><br>
Mali-G610 MC4<br><br>

<b>Camera</b><br>
Rear: Dual â 50MP (Main) + 50MP (Ultra-wide)<br>
Front: 32MP<br><br>

<b>Battery</b><br>
5,000mAh<br>
45W wired charging<br><br>

<b>OS</b><br>
Nothing OS 2.5 (based on Android 14)<br><br>

<b>Weight</b><br>
~190g<br><br>

<b>Dimensions</b><br>
~161.7 x 76.3 x 8.6 mm<br>
','',NULL),
	 (2,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744967826/majutech_products/haiacv8ecsagghuekvd2.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967829/majutech_products/hwrjwpd1n4gajyh9wzma.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967831/majutech_products/gv5lsmv7t7g2plrweose.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744967834/majutech_products/h6ymff2gsuqrhgkdulvq.png','SAMSUNG GALAXY Z FOLD6 5G','normal',6735.0,'<b>Processor</b><br>
Qualcomm Snapdragon 8 Gen 3<br><br>

<b>Memory</b><br>
12GB RAM<br><br>

<b>Storage</b><br>
256GB / 512GB / 1TB UFS 4.0<br><br>

<b>Display</b><br>
Main Display: 7.6" QXGA+ Dynamic AMOLED 2X, 120Hz<br>
Cover Display: 6.2" HD+ Dynamic AMOLED 2X, 120Hz<br><br>

<b>Graphics</b><br>
Adreno 750<br><br>

<b>Camera</b><br>
Rear: Triple â 50MP (Main) + 12MP (Ultra-wide) + 10MP (Telephoto, 3x optical zoom)<br>
Front: 10MP (Cover) + 4MP (Under Display)<br><br>

<b>Battery</b><br>
4,400mAh<br>
25W wired, 15W wireless, 4.5W reverse wireless<br><br>

<b>OS</b><br>
Android 14, One UI 6.1<br><br>

<b>Weight</b><br>
~253g<br><br>

<b>Dimensions</b><br>
Unfolded: ~154.9 x 129.9 x 6.1 mm<br>
Folded: ~154.9 x 67.1 x 13.4 mm<br>
','',NULL),
	 (5,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744968796/majutech_products/yzwglzingij3s0xhgu6n.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744968798/majutech_products/oheejwhihw19lsnqfir8.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744968800/majutech_products/hdhxnpy7vuhkqagqsthb.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744968802/majutech_products/bibdmgxx4usos6dvlv6s.png','Garmin Vivoactive 6 GPS Smartwatch','normal',1381.0,'<b>Display:</b> AMOLED touchscreen<br>
<b>Features:</b> Over 50 sport modes, running dynamics, PacePro, course following, on-watch workout animations<br>
<b>Music Storage:</b> Increased capacity<br>
<b>GPS:</b> Enhanced connectivity<br>
<b>Battery Life:</b> Extended duration<br>
<b>Design:</b> Modern aesthetic<br>
<b>Ideal For:</b> Fitness enthusiasts seeking comprehensive tracking and smartwatch functionalities<br><br>','',NULL),
	 (5,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744968867/majutech_products/ugeksypwh8cf2ohxs95q.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744968869/majutech_products/gaosymny1554lzwmxmhc.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744968871/majutech_products/t73kx93vce50fzdyqcyg.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744968874/majutech_products/gw1ielwcwdwq9vukibnh.png','Huawei Band 10','normal',129.0,'<b>Dimensions:</b> 43.45 Ã 24.86 Ã 8.99 mm<br>
<b>Strap Options:</b> Multiple colors including Black, White, Green, Blue, Purple, Pink<br>
<b>Design:</b> Slim and lightweight<br>
<b>Features:</b> Basic fitness tracking capabilities<br>
<b>Ideal For:</b> Users seeking an affordable and stylish fitness band<br><br>','',NULL),
	 (5,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744968945/majutech_products/bpnbb8zl24k1pxoc0cs5.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744968948/majutech_products/pqr4ye5bqrxlvvxrommy.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744968951/majutech_products/djixcab3p0dtwmrlgxvb.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744968953/majutech_products/d82odlendjkdtudq6e7n.png','Google Pixel Watch 3','normal',1849.0,'<b>Display:</b> 1.4â³ AMOLED<br>
<b>Processor:</b> SW5100 chipset<br>
<b>Memory:</b> 2 GB RAM, 32 GB storage<br>
<b>Battery:</b> 420 mAh, up to 24 hours with always-on display<br>
<b>Features:</b> Comprehensive fitness and lifestyle tracking<br>
<b>Ideal For:</b> Users seeking a stylish smartwatch with robust health monitoring features<br><br>','',NULL),
	 (5,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744970573/majutech_products/pgcjwaa2mmxjjz3ge5yr.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970575/majutech_products/bxordgn3gwljescy8r8e.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970577/majutech_products/f6flsmlf7lah9wrgxpti.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970579/majutech_products/qjbwlwebjcfsy7diu4xj.png','Xiaomi Smart Band 9 Pro','normal',248.0,'<b>Display:</b> 1.74â³ AMOLED, 336Ã480 resolution<br>
<b>Water Resistance:</b> 5 ATM (up to 50 meters)<br>
<b>Connectivity:</b> Bluetooth 5.4, GNSS support<br>
<b>Design:</b> Aluminum alloy frame with high-strength fiber polymer<br>
<b>Ideal For:</b> Fitness enthusiasts seeking a feature-rich and affordable smart band<br><br>','',NULL),
	 (5,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744970640/majutech_products/mitgaqvic2jw0k7nrihb.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970643/majutech_products/bxvdkgmwfshknncpay13.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970645/majutech_products/xs0iicfi5qw1rrxm5q8d.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970647/majutech_products/bnbdugfntgf5ouzwqbik.png','Garmin Instinct 3 AMOLED Rugged GPS Smartwatch','normal',2239.0,'<b>Garmin Instinct 3 AMOLED Rugged GPS Smartwatch</b><br>
<b>Display:</b> AMOLED touchscreen<br>
<b>Battery Life:</b> Up to 24 days (solar version offers extended life)<br>
<b>Features:</b> Rugged design, advanced fitness tracking, GPS, altimeter, heart rate monitoring<br>
<b>Ideal For:</b> Outdoor enthusiasts requiring a durable and long-lasting smartwatch<br><br>','',NULL),
	 (5,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744970693/majutech_products/f1fq8vqbyauxse5k9ywj.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970696/majutech_products/s2pw5ovxzy9m6ju45cqn.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970698/majutech_products/k8zudytlpfjftfhkr9ys.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970700/majutech_products/ood8vll8x1mt4zmc4z4d.png','DJI Mini 4 Pro','normal',4599.0,'<b>Weight:</b> Under 249g<br>
<b>Camera:</b> 48 MP, 4K/60fps HDR video<br>
<b>Features:</b> True Vertical Shooting, omnidirectional obstacle sensing<br>
<b>Ideal For:</b> Users seeking a lightweight drone with advanced imaging capabilities<br><br>','',NULL);
INSERT INTO MASTER.PRODUCTS (CATEGORY_ID,IMAGE1,IMAGE2,IMAGE3,IMAGE4,PRODUCT_NAME,STATUS,UNIT_PRICE,DESCRIPTION,SPECIFICATION,QUANTITY) VALUES
	 (5,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744970752/majutech_products/piaomxvdelfkrusezsfa.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970755/majutech_products/yt368sxpveosmp8hzmpe.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970757/majutech_products/podd7oj4zycrdw3b28mm.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970760/majutech_products/bmllzdpn70clhgngqbk3.png','DJI Flip','normal',1679.0,'<b>Weight:</b> Approximately 249g<br>
<b>Camera:</b> 48 MP with 1/1.3-inch CMOS sensor, 4K/60fps video<br>
<b>Design:</b> Unique folding mechanism with enclosed rotors<br>
<b>Features:</b> Multiple shooting modes, three-axis gimbal, safety features<br>
<b>Ideal For:</b> Beginners and casual users seeking a compact and safe drone<br><br>
','',NULL),
	 (5,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744970820/majutech_products/o4hdjjbtf9kksrqeiare.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970824/majutech_products/apu8hoxnmed9l7tfkbk6.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970826/majutech_products/ivpdk5bgrpmsz3mkcodl.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970831/majutech_products/sjz8sj1uuymjdk5exh8p.png','Meizu MYVU AR Smart Glasses','promotion',1883.0,'<b>Weight:</b> 43g<br>
<b>Display:</b> 0.3cc optical engine, up to 2000 nits brightness<br>
<b>Features:</b> Teleprompter functionality, dual microphones, noise cancellation<br>
<b>Battery Life:</b> Up to 4 hours of usage, 80% charge in 30 minutes<br>
<b>Ideal For:</b> Professionals needing discreet AR assistance and presentations<br><br>
','',NULL),
	 (5,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744970886/majutech_products/xyarse3qh6q5vhuvvu2v.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970888/majutech_products/fcbvkvucunnbuhkhi4o4.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970890/majutech_products/qgmb7rxipqltfcpkh9rv.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970891/majutech_products/whhnbezco1frwzuiw4gg.png','Oclean Flow Sonic Electric Toothbrush','promotion',139.0,'<b>Battery Life:</b> Up to 180 days<br>
<b>Brushing Modes:</b> 5<br>
<b>Motor:</b> 76,000 movements per minute Maglev motor<br>
<b>Features:</b> 2-minute timer with 30-second reminders, IPX7 waterproof<br>
<b>Ideal For:</b> Users seeking a long-lasting and efficient electric toothbrush<br><br>','',NULL),
	 (1,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744970920/majutech_products/pmuooj0s0pmzhm2fzjje.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970922/majutech_products/ju2apbs4sgkjcvhzpucm.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970924/majutech_products/dgajzxosujkahxtnlq5o.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744970926/majutech_products/sfxpxmnmextotg31ctx8.png','Oclean W10 Water Flosser','promotion',195.0,'<b>Pulse Frequency:</b> Up to 1400 pulses per minute<br>
<b>Water Tank:</b> 200ml detachable reservoir<br>
<b>Flossing Modes:</b> 5<br>
<b>Battery Life:</b> Up to 30 days<br>
<b>Features:</b> 15-second quad pacer, smart timer, IPX7 waterproof<br>
<b>Ideal For:</b> Individuals seeking comprehensive oral hygiene solutions<br>','',NULL),
	 (6,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744971280/majutech_products/m5cr45nsjgbskokxoe8b.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971283/majutech_products/hw8zhkagtgzapbqghshi.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971285/majutech_products/hf96o4qsq83py8vzghvp.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971288/majutech_products/b1qbdzceimq0modxfax8.png','APPLE iPad (A16)','promotion',1449.0,'<b>Processor</b><br>
Apple A16 Bionic<br><br>

<b>Memory</b><br>
6GB RAM<br><br>

<b>Storage</b><br>
128GB<br><br>

<b>Display</b><br>
10.9" Liquid Retina Display<br>
2360 x 1640 resolution<br><br>

<b>Graphics</b><br>
Apple 5-core GPU<br><br>

<b>Camera</b><br>
Rear: 12MP<br>
Front: 12MP UltraâWide<br><br>

<b>Battery</b><br>
Up to 10 hours usage<br><br>

<b>OS</b><br>
iPadOS 17<br><br>

<b>Weight</b><br>
~477g<br><br>','',NULL),
	 (6,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744971331/majutech_products/jdcx0ayhbrspmt6efndk.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971333/majutech_products/zpmchxcpho67fadeneir.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971336/majutech_products/oxzgqxnxgmb8vz84xswe.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971338/majutech_products/ucaxlgdoymrbzcsajqi1.png','Xiaomi Pad 7 Pro WiFi','promotion',2699.0,'<b>Processor</b><br>
Snapdragon 8 Gen 2<br><br>

<b>Memory</b><br>
12GB RAM<br><br>

<b>Storage</b><br>
512GB<br><br>

<b>Display</b><br>
12.4" LCD, 144Hz<br>
3048 x 2032 resolution<br><br>

<b>Graphics</b><br>
Adreno 740<br><br>

<b>Camera</b><br>
Rear: Dual 50MP + 2MP<br>
Front: 32MP<br><br>

<b>Battery</b><br>
10000mAh, 67W fast charging<br><br>

<b>OS</b><br>
HyperOS (based on Android)<br><br>

<b>Weight</b><br>
~620g<br><br>','',NULL),
	 (6,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744971406/majutech_products/qkrcguqxbscp4delsl6o.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971409/majutech_products/b40o1dmz4sqqreypqvh7.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971410/majutech_products/oebcsrfhbr1tjk5dtlca.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971411/majutech_products/diufkkdyc6cwvucnqvqj.png','Samsung Galaxy Tab A9 / A9+ Series','normal',899.0,'<b>Processor</b><br>
MediaTek Helio G99 (A9) / Snapdragon 695 (A9+)<br><br>

<b>Memory</b><br>
4GB / 8GB RAM<br><br>

<b>Storage</b><br>
64GB / 128GB<br><br>

<b>Display</b><br>
Tab A9: 8.7" TFT, WXGA+<br>
Tab A9+: 11" PLS LCD, 90Hz<br><br>

<b>Graphics</b><br>
MaliâG57 MC2 / Adreno 619<br><br>

<b>Camera</b><br>
Rear: 8MP<br>
Front: 2MP (A9) / 5MP (A9+)<br><br>

<b>Battery</b><br>
5100mAh (A9) / 7040mAh (A9+)<br><br>

<b>OS</b><br>
Android 13, One UI Core<br><br>

<b>Weight</b><br>
A9: ~366g / A9+: ~480g<br><br>
','',NULL),
	 (6,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744971534/majutech_products/dv383sbvfapwt8wurknh.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971536/majutech_products/c0a7joii5twwrgiqwoua.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971539/majutech_products/wgqc0mzkw7rrurzapns2.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971541/majutech_products/g3ohd6pkoxjcyguoudmi.png','HONOR Pad X8a Kids Edition','normal',699.0,'<b>Processor</b><br>
MediaTek Helio G88<br><br>

<b>Memory</b><br>
4GB RAM<br><br>

<b>Storage</b><br>
64GB<br><br>

<b>Display</b><br>
10.1" FHD Display<br>
1920 x 1200 resolution<br><br>

<b>Graphics</b><br>
MaliâG52 MC2<br><br>

<b>Camera</b><br>
Rear: 5MP<br>
Front: 2MP<br><br>

<b>Battery</b><br>
5100mAh<br><br>

<b>OS</b><br>
Magic UI 6.1 (based on Android 12)<br><br>

<b>Weight</b><br>
~460g (with protective case)<br><br>','',NULL),
	 (6,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744971614/majutech_products/rp2rknh49xsaqvnfjz0s.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971616/majutech_products/vgctwrlmcoiq9ospvrgy.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971619/majutech_products/zrvc4hwpgfrud5rb3vl0.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971621/majutech_products/evqkbjqvkzui12nn9kcz.png','Samsung Galaxy Tab S10 Ultra WiFi','normal',3974.0,'<b>Processor</b><br>
Snapdragon 8 Gen 3<br><br>

<b>Memory</b><br>
12GB / 16GB RAM<br><br>

<b>Storage</b><br>
256GB / 512GB / 1TB<br><br>

<b>Display</b><br>
14.6" Super AMOLED, 120Hz<br>
2960 x 1848 resolution<br><br>

<b>Graphics</b><br>
Adreno 750<br><br>

<b>Camera</b><br>
Rear: 13MP + 8MP Ultra Wide<br>
Front: 12MP + 12MP Ultra Wide<br><br>

<b>Battery</b><br>
11200mAh, 45W fast charging<br><br>

<b>OS</b><br>
Android 14, One UI 6.1<br><br>

<b>Weight</b><br>
~732g<br><br>
','',NULL),
	 (6,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744971662/majutech_products/gwj675ovhwqu6vjzutec.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971664/majutech_products/gw7hj0hw4dzblfloqzlz.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971666/majutech_products/u6xrz8scia5c7jvauc9i.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971668/majutech_products/mtsrqmfpxqednjclbdqx.png','Xiaomi Redmi Pad Pro','normal',939.0,'<b>Processor</b><br>
Snapdragon 7s Gen 2<br><br>

<b>Memory</b><br>
6GB / 8GB RAM<br><br>

<b>Storage</b><br>
128GB / 256GB<br><br>

<b>Display</b><br>
12.1" IPS LCD, 120Hz<br>
2560 x 1600 resolution<br><br>

<b>Graphics</b><br>
Adreno 710<br><br>

<b>Camera</b><br>
Rear: 8MP<br>
Front: 8MP<br><br>

<b>Battery</b><br>
10000mAh, 33W fast charging<br><br>

<b>OS</b><br>
MIUI Pad 14 (based on Android 13)<br><br>

<b>Weight</b><br>
~571g<br><br>
','',NULL);
INSERT INTO MASTER.PRODUCTS (CATEGORY_ID,IMAGE1,IMAGE2,IMAGE3,IMAGE4,PRODUCT_NAME,STATUS,UNIT_PRICE,DESCRIPTION,SPECIFICATION,QUANTITY) VALUES
	 (6,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744971715/majutech_products/mb37jnhdyzixqzyegin9.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971717/majutech_products/ytpoib4i4qyxgfauyqls.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971720/majutech_products/th0hltqfu5sqzvekfe5g.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971721/majutech_products/wtcjltwwst9vxbtsedqh.png','Apple iPad Pro 13-inch (M4)','normal',5999.0,'<b>Processor</b><br>
Apple M4 chip<br><br>

<b>Memory</b><br>
8GB / 16GB RAM<br><br>

<b>Storage</b><br>
Up to 2TB<br><br>

<b>Display</b><br>
13" Tandem OLED (Ultra Retina XDR)<br>
2752 x 2064 resolution<br><br>

<b>Graphics</b><br>
Apple 10-core GPU<br><br>

<b>Camera</b><br>
Rear: 12MP + LiDAR<br>
Front: 12MP UltraâWide<br><br>

<b>Battery</b><br>
Up to 10 hours usage<br><br>

<b>OS</b><br>
iPadOS 17<br><br>

<b>Weight</b><br>
~579g<br><br>','',NULL),
	 (6,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744971775/majutech_products/oswqu2e6hix0vcjghsae.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971778/majutech_products/l8mnfx6eagmvuqljnlbp.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971780/majutech_products/mcnwc876yzhyvlhplyi9.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971783/majutech_products/scjogbwu0jxuy0wxvgva.png','HONOR Pad 9','normal',1399.0,'<b>Processor</b><br>
Snapdragon 6 Gen 1<br><br>

<b>Memory</b><br>
8GB RAM<br><br>

<b>Storage</b><br>
256GB<br><br>

<b>Display</b><br>
12.1" 2.5K LCD, 120Hz<br>
2560 x 1600 resolution<br><br>

<b>Graphics</b><br>
Adreno 710<br><br>

<b>Camera</b><br>
Rear: 13MP<br>
Front: 8MP<br><br>

<b>Battery</b><br>
8300mAh, 35W charging<br><br>

<b>OS</b><br>
MagicOS 7.2 (based on Android 13)<br><br>

<b>Weight</b><br>
~555g<br><br>','',NULL),
	 (6,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744971822/majutech_products/rjoznhlerjwz83l4wrzi.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971824/majutech_products/tevzvzchxdnr9vw4edwx.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971826/majutech_products/g5e0jumpcxisctaff5wi.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971829/majutech_products/on3mbcs8vavivell6nk4.png','HUAWEI MatePad Pro 13.2â WiFi','normal',3599.0,'<b>Processor</b><br>
Kirin 9000s<br><br>

<b>Memory</b><br>
12GB RAM<br><br>

<b>Storage</b><br>
256GB<br><br>

<b>Display</b><br>
13.2" OLED, 144Hz<br>
2880 x 1920 resolution<br><br>

<b>Graphics</b><br>
Maleoon 910<br><br>

<b>Camera</b><br>
Rear: 13MP + 8MP<br>
Front: 16MP<br><br>

<b>Battery</b><br>
10100mAh, 88W fast charging<br><br>

<b>OS</b><br>
HarmonyOS 4.0<br><br>

<b>Weight</b><br>
~580g<br><br>
','',NULL),
	 (6,'https://res.cloudinary.com/dx91axmwl/image/upload/v1744971900/majutech_products/ybpy3ixdq8au5jbaxcl9.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971902/majutech_products/z4spondbitzkhucaec3f.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971905/majutech_products/oan62xnnvk6371ywj8cv.png','https://res.cloudinary.com/dx91axmwl/image/upload/v1744971907/majutech_products/fzn67bmuwk1egznengns.png','Apple iPad Pro 11-inch (2022) M2 Wi-Fi','normal',4649.0,'<b>Processor</b><br>
Apple M2 chip<br><br>

<b>Memory</b><br>
8GB / 16GB RAM<br><br>

<b>Storage</b><br>
Up to 2TB<br><br>

<b>Display</b><br>
11" Liquid Retina Display, 120Hz<br>
2388 x 1668 resolution<br><br>

<b>Graphics</b><br>
Apple 10-core GPU<br><br>

<b>Camera</b><br>
Rear: 12MP + 10MP UltraâWide + LiDAR<br>
Front: 12MP UltraâWide<br><br>

<b>Battery</b><br>
Up to 10 hours usage<br><br>

<b>OS</b><br>
iPadOS 16 (upgradable)<br><br>

<b>Weight</b><br>
~466g<br>

','',NULL);
